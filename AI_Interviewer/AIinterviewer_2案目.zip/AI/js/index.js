document.addEventListener('DOMContentLoaded', function () {
    const backButton = document.getElementById('next-button');
    backButton.addEventListener('click', function () {
        window.location.href = "introduction.html";
    });
});