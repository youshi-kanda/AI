document.addEventListener('DOMContentLoaded', function () {
    const backButton = document.getElementById('backButton');
    const nextButton = document.querySelector('.next-button');
    const bars = document.querySelectorAll('.bar');
    const comment = document.querySelector('.text-area p');
    const choiceArea = document.getElementById('choiceArea');
    const voiceCallButton = document.querySelector('.choice-button[onclick="startCall(\'voice\')"]'); // 音声通話ボタン
    const chatCallButton = document.querySelector('.choice-button[onclick="startCall(\'chat\')"]'); // チャット通話ボタン

    const messages = [
        'AI面接官: はじめまして。',
        'AI面接官: 私はあなたの面接を担当するAI面接官です。',
        'AI面接官: これからいくつかの質問を行いますので、リラックスしてお答えください。',
        'AI面接官: 音声入力やカメラが正しく動作しているか確認をお願いします。',
        'AI面接官: 準備が整いましたら、<br>通話方法を選んでください'
    ];

    let currentStep = 1;

    comment.innerHTML = messages[0];

    backButton.addEventListener('click', function () {
        window.location.href = 'index.html';
    });

    nextButton.addEventListener('click', function () {
        if (currentStep < bars.length) {
            bars[currentStep].classList.add('active');
        }

        if (currentStep < messages.length) {
            comment.innerHTML = messages[currentStep];
        }

        if (currentStep === messages.length - 1) {
            nextButton.style.display = 'none';
            choiceArea.style.display = 'flex';
        }

        currentStep++;
    });

    // 音声通話ボタンがクリックされたら画面遷移
    voiceCallButton.addEventListener('click', function () {
        window.location.href = 'voiceCall.html';
    });

    // チャット通話ボタンがクリックされたらchat.htmlに遷移
    chatCallButton.addEventListener('click', function () {
        window.location.href = 'chat.html';
    });
});